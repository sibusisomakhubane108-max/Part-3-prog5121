package sibusisopart1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class QuickChat {

    private String messageID;
    private int messageNumber;
    private String sender;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus;

    private static String currentSender = "";

    private static final ArrayList<QuickChat> sentMessages = new ArrayList<>();
    private static final ArrayList<QuickChat> storedMessages = new ArrayList<>();
    private static final ArrayList<QuickChat> disregardedMessages = new ArrayList<>();
    private static final ArrayList<String> messageIDs = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();

    private static final String JSON_FILE = "messages.json";

    public QuickChat(String messageID, int messageNumber, String recipient, String message) {
        this(messageID, messageNumber, recipient, message, currentSender);
    }

    public QuickChat(String messageID, int messageNumber, String recipient, String message, String sender) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.sender = (sender == null || sender.isEmpty()) ? currentSender : sender;
        this.messageHash = createMessageHash();
    }

    public static void resetState() {
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
        messageIDs.clear();
        messageHashes.clear();
        currentSender = "";
        StoredMessages.resetState();
    }

    public static void setCurrentSender(String senderCell) {
        currentSender = senderCell;
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.matches("^[0-9]{10}$");
    }

    public String checkRecipientCell() {
        if (recipient != null && (recipient.matches("^\\+27[678][0-9]{8}$") || recipient.matches("^0[678][0-9]{8}$"))) {
            return "Cell phone number successfully captured.";
        }
        return "Enter a valid South African cellphone number, for example +27716774402.";
    }

    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2 || message == null || message.trim().isEmpty()) {
            return "00:0:INVALID";
        }
        String prefix = messageID.substring(0, 2);
        String trimmedMsg = message.trim().replaceAll("[^a-zA-Z0-9\\s]", "");
        String[] words = trimmedMsg.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 0 ? words[words.length - 1] : "";
        return (prefix + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    public String SentMessage(int choice) {
        String effectiveSender = (this.sender == null || this.sender.isEmpty()) ? currentSender : this.sender;
        this.sender = effectiveSender;

        if (messageID != null && !messageIDs.contains(messageID)) {
            messageIDs.add(messageID);
        }
        if (messageHash != null && !messageHashes.contains(messageHash)) {
            messageHashes.add(messageHash);
        }

        switch (choice) {
            case 1:
                this.messageStatus = "Sent";
                sentMessages.add(this);
                StoredMessages.addSentMessage(messageID, messageHash, effectiveSender, recipient, message);
                return "Message successfully sent.";
            case 2:
                this.messageStatus = "Disregarded";
                disregardedMessages.add(this);
                StoredMessages.addDisregardedMessage(messageID, messageHash, effectiveSender, recipient, message);
                return "Message disregarded.";
            case 3:
                this.messageStatus = "Stored";
                if (!storedMessages.contains(this)) {
                    storedMessages.add(this);
                }
                StoredMessages.addStoredMessage(messageID, messageHash, effectiveSender, recipient, message);
                writeStoredMessagesToJson();
                return "Message successfully stored in " + JSON_FILE + ".";
            default:
                this.messageStatus = "Unknown";
                return "Invalid choice";
        }
    }

    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No sent messages are available.";
        }
        StringBuilder all = new StringBuilder();
        for (QuickChat sent : sentMessages) {
            all.append(sent.getMessageDetails()).append("\n");
        }
        return all.toString().trim();
    }

    public String getMessageDetails() {
        return "Message ID: " + messageID + "\n"
                + "Message Hash: " + messageHash + "\n"
                + "Recipient: " + recipient + "\n"
                + "Message: " + message + "\n"
                + "Sender: " + sender + "\n"
                + "Message Number: " + messageNumber + "\n"
                + "Status: " + messageStatus;
    }

    public boolean storeMessage() {
        String effectiveSender = (this.sender == null || this.sender.isEmpty()) ? currentSender : this.sender;
        this.sender = effectiveSender;
        this.messageStatus = "Stored";
        if (!storedMessages.contains(this)) {
            storedMessages.add(this);
        }
        StoredMessages.addStoredMessage(messageID, messageHash, effectiveSender, recipient, message);
        return writeStoredMessagesToJson();
    }

    private static boolean writeStoredMessagesToJson() {
        StringBuilder json = new StringBuilder();
        json.append("[\n");

        for (int i = 0; i < storedMessages.size(); i++) {
            QuickChat m = storedMessages.get(i);
            json.append("  {\n");
            json.append("    \"messageID\": \"").append(escapeJson(m.messageID)).append("\",\n");
            json.append("    \"messageNumber\": ").append(m.messageNumber).append(",\n");
            json.append("    \"sender\": \"").append(escapeJson(m.sender)).append("\",\n");
            json.append("    \"messageHash\": \"").append(escapeJson(m.messageHash)).append("\",\n");
            json.append("    \"recipient\": \"").append(escapeJson(m.recipient)).append("\",\n");
            json.append("    \"message\": \"").append(escapeJson(m.message)).append("\",\n");
            json.append("    \"messageStatus\": \"Stored\"\n");
            json.append("  }");

            if (i < storedMessages.size() - 1) {
                json.append(",");
            }
            json.append("\n");
        }

        json.append("]");

        try (FileWriter writer = new FileWriter(JSON_FILE)) {
            writer.write(json.toString());
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static void loadStoredMessagesFromJson() {
        try (BufferedReader reader = new BufferedReader(new FileReader(JSON_FILE))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }

            String data = content.toString().trim();
            if (data.equals("[]") || data.isEmpty()) {
                storedMessages.clear();
                StoredMessages.resetState();
                return;
            }

            if (data.startsWith("[") && data.endsWith("]")) {
                String inner = data.substring(1, data.length() - 1).trim();
                if (inner.isEmpty()) {
                    storedMessages.clear();
                    StoredMessages.resetState();
                    return;
                }

                ArrayList<QuickChat> loadedList = new ArrayList<>();
                int braceDepth = 0;
                int objStart = -1;
                boolean inQuotes = false;
                boolean escaping = false;

                for (int i = 0; i < inner.length(); i++) {
                    char ch = inner.charAt(i);
                    if (escaping) {
                        escaping = false;
                        continue;
                    }
                    if (ch == '\\' && inQuotes) {
                        escaping = true;
                        continue;
                    }
                    if (ch == '"') {
                        inQuotes = !inQuotes;
                        continue;
                    }
                    if (!inQuotes) {
                        if (ch == '{') {
                            if (braceDepth == 0) {
                                objStart = i;
                            }
                            braceDepth++;
                        } else if (ch == '}') {
                            braceDepth--;
                            if (braceDepth == 0 && objStart != -1) {
                                String objJson = inner.substring(objStart, i + 1);
                                QuickChat parsed = parseJsonObject(objJson);
                                if (parsed != null) {
                                    loadedList.add(parsed);
                                }
                                objStart = -1;
                            }
                        }
                    }
                }

                storedMessages.clear();
                storedMessages.addAll(loadedList);
                StoredMessages.resetState();

                for (QuickChat m : storedMessages) {
                    if (m.messageID != null && !messageIDs.contains(m.messageID)) {
                        messageIDs.add(m.messageID);
                    }
                    if (m.messageHash != null && !messageHashes.contains(m.messageHash)) {
                        messageHashes.add(m.messageHash);
                    }
                    String s = (m.sender == null || m.sender.isEmpty()) ? currentSender : m.sender;
                    StoredMessages.addStoredMessage(m.messageID, m.messageHash, s, m.recipient, m.message);
                }
            }
        } catch (IOException e) {
            storedMessages.clear();
        }
    }

    private static QuickChat parseJsonObject(String objJson) {
        String mID = extractJsonString(objJson, "messageID");
        int mNum = extractJsonInt(objJson, "messageNumber");
        String senderVal = extractJsonString(objJson, "sender");
        String mHash = extractJsonString(objJson, "messageHash");
        String recipientVal = extractJsonString(objJson, "recipient");
        String msgVal = extractJsonString(objJson, "message");

        if (mID.isEmpty() && msgVal.isEmpty()) {
            return null;
        }

        QuickChat loaded = new QuickChat(mID, mNum, recipientVal, msgVal, senderVal);
        if (!mHash.isEmpty()) {
            loaded.messageHash = mHash;
        }
        loaded.messageStatus = "Stored";
        return loaded;
    }

    private static String extractJsonString(String json, String key) {
        String search = "\"" + key + "\"";
        int keyIdx = json.indexOf(search);
        if (keyIdx == -1) return "";
        int colonIdx = json.indexOf(":", keyIdx + search.length());
        if (colonIdx == -1) return "";
        int firstQuote = json.indexOf("\"", colonIdx + 1);
        if (firstQuote == -1) return "";

        StringBuilder sb = new StringBuilder();
        boolean escaping = false;
        for (int i = firstQuote + 1; i < json.length(); i++) {
            char ch = json.charAt(i);
            if (escaping) {
                switch (ch) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    default: sb.append(ch); break;
                }
                escaping = false;
            } else if (ch == '\\') {
                escaping = true;
            } else if (ch == '"') {
                break;
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    private static int extractJsonInt(String json, String key) {
        String search = "\"" + key + "\"";
        int keyIdx = json.indexOf(search);
        if (keyIdx == -1) return 0;
        int colonIdx = json.indexOf(":", keyIdx + search.length());
        if (colonIdx == -1) return 0;
        String afterColon = json.substring(colonIdx + 1).trim();
        StringBuilder numStr = new StringBuilder();
        for (int i = 0; i < afterColon.length(); i++) {
            char ch = afterColon.charAt(i);
            if (Character.isDigit(ch) || (i == 0 && ch == '-')) {
                numStr.append(ch);
            } else if (numStr.length() > 0) {
                break;
            }
        }
        try {
            return Integer.parseInt(numStr.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static String escapeJson(String text) {
        if (text == null) return "";
        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    public static String displaySenderAndRecipient() {
        return StoredMessages.displaySenderAndRecipient();
    }

    public static String displayLongestStoredMessage() {
        return StoredMessages.displayLongestStoredMessage();
    }

    public static String searchMessageID(String id) {
        return StoredMessages.searchMessageID(id);
    }

    public static String searchStoredByRecipient(String targetRecipient) {
        return StoredMessages.searchStoredByRecipient(targetRecipient);
    }

    public static String deleteByMessageHash(String hash) {
        storedMessages.removeIf(m -> m.messageHash != null && m.messageHash.equalsIgnoreCase(hash));
        messageHashes.removeIf(h -> h != null && h.equalsIgnoreCase(hash));
        writeStoredMessagesToJson();
        return StoredMessages.deleteByMessageHash(hash);
    }

    public static String displayStoredReport() {
        return StoredMessages.displayStoredReport();
    }

    public static String searchByRecipient(String targetRecipient) {
        return StoredMessages.searchByRecipient(targetRecipient);
    }

    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    public static String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long) (rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    public static void printMessageDetails(QuickChat m) {
        System.out.println(m.getMessageDetails());
    }

    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public String getMessageStatus() { return messageStatus; }
}