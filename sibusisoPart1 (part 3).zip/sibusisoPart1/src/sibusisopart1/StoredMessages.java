package sibusisopart1;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class StoredMessages {

    private static final String DEFAULT_JSON_FILE = "storedMessages.json";
    private static String jsonFilePath = DEFAULT_JSON_FILE;

    // Required Part 3 arrays (dynamically resized, no hard-coding)
    private static String[] sentMessages = new String[0];
    private static String[] disregardedMessages = new String[0];
    private static String[] storedMessages = new String[0];
    private static String[] messageHashes = new String[0];
    private static String[] messageIDs = new String[0];

    // Parallel arrays for senders, recipients, and message text across all recorded items
    private static String[] allMessages = new String[0];
    private static String[] senders = new String[0];
    private static String[] recipients = new String[0];

    // Parallel arrays specifically aligned with storedMessages
    private static String[] storedSenders = new String[0];
    private static String[] storedRecipients = new String[0];
    private static String[] storedHashes = new String[0];
    private static String[] storedIDs = new String[0];

    public static void setJsonFilePath(String path) {
        jsonFilePath = (path == null || path.trim().isEmpty()) ? DEFAULT_JSON_FILE : path.trim();
    }

    public static String getJsonFilePath() {
        return jsonFilePath;
    }

    public static String[] getSentMessages() {
        return Arrays.copyOf(sentMessages, sentMessages.length);
    }

    public static String[] getDisregardedMessages() {
        return Arrays.copyOf(disregardedMessages, disregardedMessages.length);
    }

    public static String[] getStoredMessages() {
        return Arrays.copyOf(storedMessages, storedMessages.length);
    }

    public static String[] getMessageHashes() {
        return Arrays.copyOf(messageHashes, messageHashes.length);
    }

    public static String[] getMessageIDs() {
        return Arrays.copyOf(messageIDs, messageIDs.length);
    }

    public static void addSentMessage(String messageID, String messageHash, String sender, String recipient, String message) {
        appendMasterEntry(messageID, messageHash, sender, recipient, message);
        sentMessages = appendString(sentMessages, message);
    }

    public static void addDisregardedMessage(String messageID, String messageHash, String sender, String recipient, String message) {
        appendMasterEntry(messageID, messageHash, sender, recipient, message);
        disregardedMessages = appendString(disregardedMessages, message);
    }

    public static void addStoredMessage(String messageID, String messageHash, String sender, String recipient, String message) {
        appendMasterEntry(messageID, messageHash, sender, recipient, message);
        appendStoredEntry(messageID, messageHash, sender, recipient, message);
        saveStoredMessagesToJson();
    }

    private static void appendMasterEntry(String messageID, String messageHash, String sender, String recipient, String message) {
        messageIDs = appendString(messageIDs, safe(messageID));
        messageHashes = appendString(messageHashes, safe(messageHash));
        senders = appendString(senders, safe(sender));
        recipients = appendString(recipients, safe(recipient));
        allMessages = appendString(allMessages, safe(message));
    }

    private static void appendStoredEntry(String messageID, String messageHash, String sender, String recipient, String message) {
        storedMessages = appendString(storedMessages, safe(message));
        storedSenders = appendString(storedSenders, safe(sender));
        storedRecipients = appendString(storedRecipients, safe(recipient));
        storedHashes = appendString(storedHashes, safe(messageHash));
        storedIDs = appendString(storedIDs, safe(messageID));
    }

    @SuppressWarnings("unchecked")
    public static void saveStoredMessagesToJson() {
        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < storedMessages.length; i++) {
            JSONObject obj = new JSONObject();
            obj.put("messageID", i < storedIDs.length ? storedIDs[i] : "");
            obj.put("messageHash", i < storedHashes.length ? storedHashes[i] : "");
            obj.put("sender", i < storedSenders.length ? storedSenders[i] : "");
            obj.put("recipient", i < storedRecipients.length ? storedRecipients[i] : "");
            obj.put("message", storedMessages[i]);
            jsonArray.add(obj);
        }

        File file = new File(jsonFilePath);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(jsonArray.toJSONString());
            writer.flush();
        } catch (IOException e) {
            throw new IllegalStateException("Error writing stored messages JSON: " + jsonFilePath, e);
        }
    }

    public static String[] loadStoredMessagesFromJson() {
        clearStoredArraysOnly();

        File file = new File(jsonFilePath);
        if (!file.exists() || file.length() == 0) {
            return getStoredMessages();
        }

        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(file)) {
            Object parsed = parser.parse(reader);
            if (parsed instanceof JSONArray) {
                JSONArray array = (JSONArray) parsed;
                for (Object item : array) {
                    if (item instanceof JSONObject) {
                        JSONObject obj = (JSONObject) item;
                        String id = safe(obj.get("messageID"));
                        String hash = safe(obj.get("messageHash"));
                        String sender = safe(obj.get("sender"));
                        String recipient = safe(obj.get("recipient"));
                        String msg = safe(obj.get("message"));

                        appendStoredEntry(id, hash, sender, recipient, msg);
                        appendMasterEntry(id, hash, sender, recipient, msg);
                    }
                }
            }
        } catch (IOException | ParseException e) {
            throw new IllegalStateException("Error reading stored messages JSON: " + jsonFilePath, e);
        }

        return getStoredMessages();
    }

    // 2a. Display sender and recipient of all stored messages
    public static String displaySenderAndRecipient() {
        if (storedMessages.length == 0) {
            return "No stored messages available.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < storedMessages.length; i++) {
            if (i > 0) {
                sb.append("\n");
            }
            sb.append("Sender: ").append(storedSenders[i])
              .append(" | Recipient: ").append(storedRecipients[i]);
        }
        return sb.toString();
    }

    // 2b. Display the longest stored message
    public static String displayLongestStoredMessage() {
        if (storedMessages.length == 0) {
            return "No stored messages available.";
        }
        String longest = storedMessages[0];
        for (int i = 1; i < storedMessages.length; i++) {
            if (storedMessages[i].length() > longest.length()) {
                longest = storedMessages[i];
            }
        }
        return longest;
    }

    // 2c. Search for a message ID and display corresponding recipient and message
    public static String searchMessageID(String targetID) {
        if (targetID == null || targetID.trim().isEmpty()) {
            return "Message ID not found.";
        }
        String needle = targetID.trim();
        for (int i = 0; i < messageIDs.length; i++) {
            if (needle.equals(messageIDs[i])) {
                return "Recipient: " + recipients[i] + " | Message: " + allMessages[i];
            }
        }
        return "Message ID not found.";
    }

    // 2d. Search for all messages stored for a particular recipient
    public static String searchStoredByRecipient(String recipient) {
        if (recipient == null || recipient.trim().isEmpty()) {
            return "No stored messages found for recipient.";
        }
        String needle = recipient.trim();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < storedRecipients.length; i++) {
            if (needle.equals(storedRecipients[i])) {
                if (sb.length() > 0) {
                    sb.append("\n");
                }
                sb.append(storedMessages[i]);
            }
        }
        return sb.length() == 0 ? "No stored messages found for recipient: " + needle : sb.toString();
    }

    // 2e. Delete a message using the message hash
    public static String deleteByMessageHash(String hash) {
        if (hash == null || hash.trim().isEmpty()) {
            return "Message hash not found.";
        }
        String needle = hash.trim();

        for (int i = 0; i < storedHashes.length; i++) {
            if (needle.equals(storedHashes[i])) {
                String deletedText = storedMessages[i];
                storedMessages = removeAt(storedMessages, i);
                storedSenders = removeAt(storedSenders, i);
                storedRecipients = removeAt(storedRecipients, i);
                storedHashes = removeAt(storedHashes, i);
                storedIDs = removeAt(storedIDs, i);
                removeMasterByHash(needle);
                saveStoredMessagesToJson();
                return "Message: \"" + deletedText + "\" successfully deleted.";
            }
        }

        for (int i = 0; i < messageHashes.length; i++) {
            if (needle.equals(messageHashes[i])) {
                String deletedText = allMessages[i];
                messageIDs = removeAt(messageIDs, i);
                messageHashes = removeAt(messageHashes, i);
                senders = removeAt(senders, i);
                recipients = removeAt(recipients, i);
                allMessages = removeAt(allMessages, i);
                sentMessages = removeValueOnce(sentMessages, deletedText);
                disregardedMessages = removeValueOnce(disregardedMessages, deletedText);
                return "Message: \"" + deletedText + "\" successfully deleted.";
            }
        }

        return "Message hash not found.";
    }

    private static void removeMasterByHash(String hash) {
        for (int i = 0; i < messageHashes.length; i++) {
            if (hash.equals(messageHashes[i])) {
                messageIDs = removeAt(messageIDs, i);
                messageHashes = removeAt(messageHashes, i);
                senders = removeAt(senders, i);
                recipients = removeAt(recipients, i);
                allMessages = removeAt(allMessages, i);
                return;
            }
        }
    }

    // 2f. Display a report that lists full details of all stored messages
    public static String displayStoredReport() {
        if (storedMessages.length == 0) {
            return "No stored messages to display.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < storedMessages.length; i++) {
            if (i > 0) {
                sb.append("\n----------------\n");
            }
            sb.append("Message ID: ").append(storedIDs[i]).append("\n")
              .append("Message Hash: ").append(storedHashes[i]).append("\n")
              .append("Sender: ").append(storedSenders[i]).append("\n")
              .append("Recipient: ").append(storedRecipients[i]).append("\n")
              .append("Message: ").append(storedMessages[i]);
        }
        return sb.toString();
    }

    // Search all sent and stored messages for a particular recipient
    public static String searchByRecipient(String recipient) {
        if (recipient == null || recipient.trim().isEmpty()) {
            return "No messages found for recipient.";
        }
        String needle = recipient.trim();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < recipients.length; i++) {
            if (needle.equals(recipients[i])) {
                if (sb.length() > 0) {
                    sb.append("\n");
                }
                sb.append(allMessages[i]);
            }
        }
        return sb.length() == 0 ? "No messages found for recipient: " + needle : sb.toString();
    }

    private static void clearStoredArraysOnly() {
        storedMessages = new String[0];
        storedSenders = new String[0];
        storedRecipients = new String[0];
        storedHashes = new String[0];
        storedIDs = new String[0];
    }

    public static void resetState() {
        sentMessages = new String[0];
        disregardedMessages = new String[0];
        allMessages = new String[0];
        senders = new String[0];
        recipients = new String[0];
        messageHashes = new String[0];
        messageIDs = new String[0];
        clearStoredArraysOnly();
        jsonFilePath = DEFAULT_JSON_FILE;
    }

    private static String[] appendString(String[] array, String value) {
        String[] copy = Arrays.copyOf(array, array.length + 1);
        copy[array.length] = value;
        return copy;
    }

    private static String[] removeAt(String[] array, int index) {
        if (index < 0 || index >= array.length) {
            return array;
        }
        String[] result = new String[array.length - 1];
        System.arraycopy(array, 0, result, 0, index);
        System.arraycopy(array, index + 1, result, index, array.length - index - 1);
        return result;
    }

    private static String[] removeValueOnce(String[] array, String target) {
        for (int i = 0; i < array.length; i++) {
            if (target.equals(array[i])) {
                return removeAt(array, i);
            }
        }
        return array;
    }

    private static String safe(Object val) {
        return val == null ? "" : val.toString();
    }
}