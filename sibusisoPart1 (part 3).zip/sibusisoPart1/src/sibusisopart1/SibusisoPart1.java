package sibusisopart1;

import java.util.Scanner;

public class SibusisoPart1 {

    public String name;
    public String surname;
    public String username;
    public String password;
    public String cellPhoneNumber;

    public static void main(String[] args) {

        Scanner inputDevice = new Scanner(System.in);

        System.out.println("===== USER REGISTRATION =====");

        // Enter name (must not be blank)
        String name;
        while (true) {
            System.out.print("Enter your first name: ");
            name = inputDevice.nextLine().trim();
            if (!name.isEmpty()) {
                break;
            }
            System.out.println("First name cannot be empty.");
        }

        // Enter surname (must not be blank)
        String surname;
        while (true) {
            System.out.print("Enter your surname: ");
            surname = inputDevice.nextLine().trim();
            if (!surname.isEmpty()) {
                break;
            }
            System.out.println("Surname cannot be empty.");
        }

        // Register username
        String username;
        while (true) {
            System.out.print("Enter your username: ");
            username = inputDevice.nextLine();

            if (checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; it must contain an underscore and be no more than five characters in length.");
            }
        }

        // Register password
        String password;
        while (true) {
            System.out.print("Enter your password: ");
            password = inputDevice.nextLine();

            if (checkPassword(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password must contain at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        // Register South African cellphone number (+27 + 6/7/8 + 8 more digits = 12 chars)
        String cellPhoneNumber;
        while (true) {
            System.out.print("Enter your cellphone number (e.g. +27838968976): ");
            cellPhoneNumber = inputDevice.nextLine().trim();

            if (checkCellPhoneNumber(cellPhoneNumber)) {
                System.out.println("Cell number successfully captured.");
                break;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain a valid South African international code.");
            }
        }

        System.out.println();
        System.out.println("Registration successful!");

        SibusisoPart1 user = new SibusisoPart1();
        user.name = name;
        user.surname = surname;
        user.username = username;
        user.password = password;
        user.cellPhoneNumber = cellPhoneNumber;

        QuickChat.setCurrentSender(cellPhoneNumber);
        StoredMessages.loadStoredMessagesFromJson();

        boolean loginSuccess = login.loginUser(inputDevice, user);
        if (!loginSuccess) {
            inputDevice.close();
            return;
        }

        // ==================== QUICKCHAT MENU ====================
        System.out.println();
        System.out.println("Welcome to QuickChat.");

        boolean running = true;

        while (running) {
            System.out.println();
            System.out.println("QUICKCHAT MENU");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Choose an option: ");

            String option = inputDevice.nextLine().trim();

            switch (option) {
                case "1":
                    int numberOfMessages = 0;
                    while (numberOfMessages <= 0) {
                        System.out.print("How many messages would you like to enter? ");
                        String rawCount = inputDevice.nextLine().trim();
                        try {
                            numberOfMessages = Integer.parseInt(rawCount);
                        } catch (NumberFormatException e) {
                            numberOfMessages = 0;
                        }
                        if (numberOfMessages <= 0) {
                            System.out.println("Please enter a whole number greater than zero.");
                        }
                    }

                    for (int i = 0; i < numberOfMessages; i++) {
                        int messageNum = i + 1;
                        System.out.println("\n--- Message " + messageNum + " of " + numberOfMessages + " ---");

                        // Recipient validation (accepts valid +27 SA numbers or local SA mobile numbers)
                        String recipient;
                        while (true) {
                            System.out.print("Enter recipient cellphone number: ");
                            recipient = inputDevice.nextLine().trim();

                            QuickChat tempCheck = new QuickChat("0000000000", messageNum, recipient, "", cellPhoneNumber);
                            String result = tempCheck.checkRecipientCell();
                            System.out.println(result);

                            if (result.equals("Cell phone number successfully captured.")) {
                                break;
                            }
                        }

                        // Message text validation (1 to 250 non-blank characters)
                        String messageText;
                        while (true) {
                            System.out.print("Enter your message: ");
                            messageText = inputDevice.nextLine();

                            if (messageText.trim().isEmpty()) {
                                System.out.println("Message cannot be empty.");
                            } else if (messageText.length() > 250) {
                                int overBy = messageText.length() - 250;
                                System.out.println("Message exceeds 250 characters by " + overBy + "; please reduce the size.");
                            } else {
                                System.out.println("Message ready to send.");
                                break;
                            }
                        }

                        String messageID = QuickChat.generateMessageID();
                        QuickChat newMessage = new QuickChat(messageID, messageNum, recipient, messageText, cellPhoneNumber);

                        System.out.println("Message ID: " + messageID);
                        System.out.println("Message Hash: " + newMessage.getMessageHash());
                        System.out.println("1. Send Message");
                        System.out.println("2. Disregard Message");
                        System.out.println("3. Store Message to send later");

                        int choice = 0;
                        while (choice < 1 || choice > 3) {
                            System.out.print("Enter your choice: ");
                            String entry = inputDevice.nextLine().trim();
                            if (entry.equals("1") || entry.equals("2") || entry.equals("3")) {
                                choice = Integer.parseInt(entry);
                            } else {
                                System.out.println("Please select 1, 2 or 3.");
                            }
                        }

                        System.out.println(newMessage.SentMessage(choice));

                        if (choice == 1) {
                            QuickChat.printMessageDetails(newMessage);
                        }
                    }
                    break;

                case "2":
                    System.out.println(QuickChat.printMessages());
                    break;

                case "3":
                    running = false;
                    System.out.println("Total messages sent: " + QuickChat.returnTotalMessages());
                    System.out.println("Thank you for using QuickChat.");
                    break;

                // ==================== PART 3 STARTS HERE (Stored Messages Menu & Operations) ====================
                case "4":
                    boolean storedMenuRunning = true;
                    while (storedMenuRunning) {
                        System.out.println();
                        System.out.println("STORED MESSAGES MENU");
                        System.out.println("1. Display sender and recipient of all stored messages");
                        System.out.println("2. Display the longest stored message");
                        System.out.println("3. Search for a message ID");
                        System.out.println("4. Search stored messages by recipient");
                        System.out.println("5. Delete a message using message hash");
                        System.out.println("6. Display full report of all stored messages");
                        System.out.println("7. Search all (sent and stored) messages by recipient");
                        System.out.println("8. Return to Main Menu");
                        System.out.print("Choose an option: ");

                        String subOption = inputDevice.nextLine().trim();

                        switch (subOption) {
                            case "1":
                                System.out.println(StoredMessages.displaySenderAndRecipient());
                                break;
                            case "2":
                                System.out.println(StoredMessages.displayLongestStoredMessage());
                                break;
                            case "3":
                                System.out.print("Enter the message ID: ");
                                String searchId = inputDevice.nextLine().trim();
                                System.out.println(StoredMessages.searchMessageID(searchId));
                                break;
                            case "4":
                                System.out.print("Enter the recipient's cellphone number: ");
                                String searchStoredRecip = inputDevice.nextLine().trim();
                                System.out.println(StoredMessages.searchStoredByRecipient(searchStoredRecip));
                                break;
                            case "5":
                                System.out.print("Enter the message hash: ");
                                String searchHash = inputDevice.nextLine().trim();
                                System.out.println(StoredMessages.deleteByMessageHash(searchHash));
                                break;
                            case "6":
                                System.out.println(StoredMessages.displayStoredReport());
                                break;
                            case "7":
                                System.out.print("Enter the recipient's cellphone number: ");
                                String searchAllRecip = inputDevice.nextLine().trim();
                                System.out.println(StoredMessages.searchByRecipient(searchAllRecip));
                                break;
                            case "8":
                                storedMenuRunning = false;
                                break;
                            default:
                                System.out.println("Invalid option. Choose a number from 1 to 8.");
                        }
                    }
                    break;
                // ==================== PART 3 ENDS HERE ====================

                default:
                    System.out.println("Invalid option. Please choose 1, 2, 3, or 4.");
            }
        }

        inputDevice.close();
    }

    public static boolean checkUserName(String username) {
        return username != null && username.length() <= 5 && username.contains("_");
    }

    public static boolean checkCellPhoneNumber(String cellPhoneNumber) {
        return cellPhoneNumber != null && cellPhoneNumber.matches("^\\+27[678][0-9]{8}$");
    }

    public static boolean checkPassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);
            if (Character.isUpperCase(ch)) {
                hasCapitalLetter = true;
            }
            if (Character.isDigit(ch)) {
                hasNumber = true;
            }
            if (!Character.isLetterOrDigit(ch)) {
                hasSpecialCharacter = true;
            }
        }

        return hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }
}