package sibusisopart1;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class StoredMessagesIT {

    private File tempJsonFile;

    @Before
    public void setUp() throws IOException {
        QuickChat.resetState();
        StoredMessages.resetState();

        tempJsonFile = Files.createTempFile("stored-messages-test-", ".json").toFile();
        tempJsonFile.deleteOnExit();
        StoredMessages.setJsonFilePath(tempJsonFile.getAbsolutePath());
    }

    @After
    public void tearDown() {
        QuickChat.resetState();
        StoredMessages.resetState();
        if (tempJsonFile != null && tempJsonFile.exists()) {
            tempJsonFile.delete();
        }
    }

    private void populateSpecTestData() {
        String sender = "+27838968976";

        // Test Data Message 1: Recipient +27834557896 | "Did you get the cake?" | Sent
        QuickChat msg1 = new QuickChat("1000000001", 1, "+27834557896", "Did you get the cake?", sender);
        msg1.SentMessage(1);

        // Test Data Message 2: Recipient +27838884567 | "Where are you? You are late! I have asked you to be on time." | Stored
        QuickChat msg2 = new QuickChat("1000000002", 2, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", sender);
        msg2.SentMessage(3);

        // Test Data Message 3: Recipient +27834484567 | "Yohoooo, I am at your gate." | Disregard
        QuickChat msg3 = new QuickChat("1000000003", 3, "+27834484567", "Yohoooo, I am at your gate.", sender);
        msg3.SentMessage(2);

        // Test Data Message 4: Recipient/Developer 0838884567 | "It is dinner time !" | Sent
        QuickChat msg4 = new QuickChat("1000000004", 4, "0838884567", "It is dinner time !", sender);
        msg4.SentMessage(1);

        // Test Data Message 5: Recipient +27838884567 | "Ok, I am leaving without you." | Stored
        QuickChat msg5 = new QuickChat("1000000005", 5, "+27838884567", "Ok, I am leaving without you.", sender);
        msg5.SentMessage(3);
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        populateSpecTestData();

        String[] sent = StoredMessages.getSentMessages();
        assertEquals(2, sent.length);
        assertEquals("Did you get the cake?", sent[0]);
        assertEquals("It is dinner time !", sent[1]);
    }

    @Test
    public void testDisplayLongestStoredMessage() {
        populateSpecTestData();

        String longest = StoredMessages.displayLongestStoredMessage();
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }

    @Test
    public void testSearchByMessageID() {
        populateSpecTestData();

        String result = StoredMessages.searchMessageID("1000000004");
        assertTrue(result.contains("0838884567"));
        assertTrue(result.contains("It is dinner time !"));
    }

    @Test
    public void testSearchSentOrStoredByRecipient() {
        populateSpecTestData();

        String result = StoredMessages.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessageUsingHash() {
        populateSpecTestData();

        QuickChat msg2 = new QuickChat("1000000002", 2, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", "+27838968976");
        String deletedResponse = StoredMessages.deleteByMessageHash(msg2.getMessageHash());

        assertEquals(
                "Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
                deletedResponse
        );
        assertEquals(1, StoredMessages.getStoredMessages().length);
    }

    @Test
    public void testDisplayStoredReport() {
        populateSpecTestData();

        String report = StoredMessages.displayStoredReport();
        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient: +27838884567"));
        assertTrue(report.contains("Message: Where are you? You are late! I have asked you to be on time."));
        assertTrue(report.contains("Message: Ok, I am leaving without you."));
    }
}