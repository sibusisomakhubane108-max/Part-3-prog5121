package sibusisopart1;

import java.io.File;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class QuickChatTest {

    @Before
    public void setUp() {
        QuickChat.resetState();
        File file = new File("messages.json");
        if (file.exists()) {
            //noinspection ResultOfMethodCallIgnored
            file.delete();
        }
    }

    @After
    public void tearDown() {
        QuickChat.resetState();
        File file = new File("messages.json");
        if (file.exists()) {
            //noinspection ResultOfMethodCallIgnored
            file.delete();
        }
    }

    @Test
    public void testCheckUserName() {
        assertTrue(
            "Valid username should contain an underscore and be 5 characters or less",
            SibusisoPart1.checkUserName("sib_1")
        );

        assertFalse(
            "Username without an underscore should be invalid",
            SibusisoPart1.checkUserName("sibusiso")
        );

        assertFalse(
            "Username longer than 5 characters should be invalid",
            SibusisoPart1.checkUserName("sib_123")
        );
    }

    @Test
    public void testCheckPassword() {
        assertTrue(
            "Valid password should contain 8+ characters, capital letter, number and special character",
            SibusisoPart1.checkPassword("Password1!")
        );

        assertFalse(
            "Password without a capital letter should be invalid",
            SibusisoPart1.checkPassword("password1!")
        );

        assertFalse(
            "Password without a number should be invalid",
            SibusisoPart1.checkPassword("Password!")
        );

        assertFalse(
            "Password without a special character should be invalid",
            SibusisoPart1.checkPassword("Password1")
        );

        assertFalse(
            "Password shorter than 8 characters should be invalid",
            SibusisoPart1.checkPassword("Pass1!")
        );
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(
            "Phone number with international code should be valid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567")
        );

        assertFalse(
            "Phone number without international code should be invalid",
            SibusisoPart1.checkCellPhoneNumber("0821234567")
        );

        assertFalse(
            "Phone number longer than 13 characters should be invalid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567890")
        );
    }

    @Test
    public void testCheckMessageID() {
        QuickChat validChat = new QuickChat("1234567890", 0, "+27821234567", "Hello");
        assertTrue("Message ID of 10 digits should be valid", validChat.checkMessageID());

        QuickChat invalidChat = new QuickChat("1234567890123", 0, "+27821234567", "Hello");
        assertFalse("Message ID longer than 10 digits should be invalid", invalidChat.checkMessageID());
    }

    @Test
    public void testCheckRecipientCell() {
        QuickChat validChat = new QuickChat("1234567890", 0, "+27821234567", "Hello");
        assertEquals("Cell phone number successfully captured.", validChat.checkRecipientCell());

        QuickChat invalidChat = new QuickChat("1234567890", 0, "12345", "Hello");
        assertEquals(
            "Enter a valid South African cellphone number, for example +27716774402.",
            invalidChat.checkRecipientCell()
        );
    }

    @Test
    public void testCreateMessageHash() {
        QuickChat chat = new QuickChat("1234567890", 0, "+27821234567", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("12:0:HITONIGHT", chat.createMessageHash());
    }

    @Test
    public void testSentMessageOptions() {
        QuickChat chat = new QuickChat("1234567890", 0, "+27821234567", "Test message");

        assertEquals("Message successfully sent.", chat.SentMessage(1));
        assertEquals("Message disregarded.", chat.SentMessage(2));
        assertEquals("Message successfully stored in messages.json.", chat.SentMessage(3));
        assertEquals("Invalid choice", chat.SentMessage(99));
    }

    @Test
    public void testReturnTotalMessages() {
        int initialCount = QuickChat.returnTotalMessages();
        QuickChat chat = new QuickChat("1234567890", 0, "+27821234567", "Test message");
        chat.SentMessage(1);
        assertEquals(initialCount + 1, QuickChat.returnTotalMessages());
    }

    @Test
    public void testReturnLoginStatus() {
        SibusisoPart1 user = new SibusisoPart1();
        user.name = "Sibusiso";
        user.surname = "Mkhize";

        String successMsg = login.returnLoginStatus(user, true);
        assertEquals("Welcome Sibusiso, Mkhize it is great to see you again.", successMsg);

        String failureMsg = login.returnLoginStatus(user, false);
        assertEquals("Username or password incorrect, please try again.", failureMsg);
    }
}