package sibusisopart1;

import org.junit.Test;
import static org.junit.Assert.*;

public class SibusisoPart1Test {

    @Test
    public void testCheckUserName() {
        assertTrue(
            "Valid username should contain an underscore and be 5 characters or less",
            SibusisoPart1.checkUserName("kyl_1")
        );

        assertFalse(
            "Username without an underscore should be invalid",
            SibusisoPart1.checkUserName("kyle1")
        );

        assertFalse(
            "Username longer than 5 characters should be invalid",
            SibusisoPart1.checkUserName("kyle_123")
        );
    }

    @Test
    public void testCheckPassword() {
        assertTrue(
            "Valid password should contain 8+ characters, capital letter, number and special character",
            SibusisoPart1.checkPassword("Password1!")
        );

        assertFalse(
            "Password without a capital letter should be invalid",
            SibusisoPart1.checkPassword("password1!")
        );

        assertFalse(
            "Password without a number should be invalid",
            SibusisoPart1.checkPassword("Password!")
        );

        assertFalse(
            "Password without a special character should be invalid",
            SibusisoPart1.checkPassword("Password1")
        );

        assertFalse(
            "Password shorter than 8 characters should be invalid",
            SibusisoPart1.checkPassword("Pass1!")
        );
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(
            "Phone number with international code should be valid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567")
        );

        assertFalse(
            "Phone number without international code should be invalid",
            SibusisoPart1.checkCellPhoneNumber("0821234567")
        );

        assertFalse(
            "Phone number longer than 13 characters should be invalid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567890")
        );
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        SibusisoPart1 user = new SibusisoPart1();
        user.name = "Sibusiso";
        user.surname = "Mkhize";
        user.username = "sib_1";
        user.password = "Password1!";

        String successMessage = login.returnLoginStatus(user, true);

        assertEquals(
            "Welcome Sibusiso, Mkhize it is great to see you again.",
            successMessage
        );
    }

    @Test
    public void testReturnLoginStatusFailure() {
        SibusisoPart1 user = new SibusisoPart1();

        String failureMessage = login.returnLoginStatus(user, false);

        assertEquals(
            "Username or password incorrect, please try again.",
            failureMessage
        );
    }
}